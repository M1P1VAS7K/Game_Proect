import pygame
import random
import sys
from pygame import *
import sqlite3
from bush import checker

pygame.init()
pygame.mixer.init()

# music
# pygame.mixer.music.load('music.mp3')
# pygame.mixer.music.play()
# pygame.mixer.music.set_volume(0.25)

# sound
sound_fire_1 = pygame.mixer.Sound('fire_sound.mp3')
sound_fire_2 = pygame.mixer.Sound('sound_ef_2.mp3')
sound_fire_3 = pygame.mixer.Sound('no_ammo.mp3')
sound_shield_up = pygame.mixer.Sound('shield_up.mp3')
sound_med_up = pygame.mixer.Sound('med_up.mp3')
sound_coin_up = pygame.mixer.Sound('coin_up.mp3')
sound_bullet_up = pygame.mixer.Sound('bullet_up.mp3')
sound_lvl_end = pygame.mixer.Sound('lvl_end.mp3')
run = [pygame.mixer.Sound('shag_1.mp3'), pygame.mixer.Sound('shag_2.mp3')]
mob_dd = [pygame.mixer.Sound('popadanie_v_moba_1.mp3'), pygame.mixer.Sound('popadanie_v_moba_2.mp3'),
          pygame.mixer.Sound('popadanie_v_moba_3.mp3')]
lvl_dd = pygame.mixer.Sound('popadanie_v_lvl.mp3')
player_dead = pygame.mixer.Sound('dead_player_sound.mp3')
player_hp = pygame.mixer.Sound('-hp.mp3')
player_sh = pygame.mixer.Sound('brake_shield.mp3')
monster_dd = pygame.mixer.Sound('monster_dead.mp3')
# переменные
w, h = x, y = size = 1250, 800
game = True
l = False
r = False
up = False
on_sprite = False
crouch = False
_hp = 0
_sh = 0
speed = 8
jump = -15
F_Down = 1
list_platforms_for_me = []
list_box = []
list_bullet = []
platforms = []
list_of_traps = []
list_mob = []
list_player = []
list_escape = []
start_screen = True
stop_screen_v = False
name_player = 'player'
num_level = 1
update = True
clear = False
#level
level = [[" --------------------------------------------------------------------------------------------------------",
          " -                                                                                                 .    -",
          " -                                                                                                      -",
          " -                                                                                               --------",
          " -                     -                                                                    -           -",
          " -       -                                             -                             -                  -",
          " -                                -                                           -                         -",
          " -                                                                     -                                -",
          " -                  -                                        -              -                           -",
          " -  -        -                                                          -       -                       -",
          " -                                                  -                               -                   -",
          " -                                  -                          -                         -              -",
          " -                  -        -             -                                                  -         -",
          " -           -                                                                               -        - -",
          " -                                                                                     -                -",
          " -               -                                         -                                         -  -",
          " -                  -                                                             -              -      -",
          " -                                            -                            -                  -         -",
          " -                      -                                               -                 -             -",
          " -                                                                   -                 -                -",
          " -                           -                                   -                                      -",
          " -                                                     -                         -                      -",
          " -                                  -                                        -                          -",
          " -^^^^^^^^^^^^^^^^                      -     -                                   +                     -",
          " -+++++++++++++++ -                                                      -           +   +       +/ / / -",
          " -                -                                   -     -         -----------------------------------",
          " ------------------                                                                                     -",
          " -                                                                 -                                    -",
          " -                                                               -                                      -",
          " -                                                    +       ++-                                       -",
          " -                                                ---------------                                       -",
          " -                                -        -                                                            -",
          " -                        -                                                                      --------",
          " - *                                                                                             -+  +  -",
          " -       / / / / /                                                                               -      -",
          " --------------------------------------------------------------------------------------------------------",
          ],
         ["",
          "-                                     -",
          "-                                 .   -",
          "-                                     -",
          "-                          - ---------",
          "-                      -  -           -",
          "-*           -   -   -                -",
          "-     -                               -",
          "-------^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^^"],
         ["-------------------------------------",
          "-                                    -",
          "-                     --             -",
          "-                        ---         -",
          "-                         --         -",
          "-                   --               -",
          "-     *     .             -          -",
          "-                                    -",
          "--------------------------------------"]
         ]
#level
#load_images
bg = pygame.image.load('10.jpg')
ak_im = pygame.image.load('ak_image.png')
bull_im = pygame.transform.scale(pygame.image.load('bullet.png'), (5, 5))
bull_im.set_colorkey((255, 255, 255))
cl_box_im = pygame.image.load('box_close.png')
box_hp = pygame.image.load('box_hp.png')
box_hp.set_colorkey((255, 255, 255))
box_sh = pygame.image.load('box_sh.png')
box_sh.set_colorkey((255, 255, 255))
box_bul = pygame.image.load('box_bul.png')
box_bul.set_colorkey((255, 255, 255))
box_coin = pygame.image.load('box_coin.png')
box_coin.set_colorkey((255, 255, 255))

spisok_mob_1_l = []
pic = pygame.image.load('slime.png')
for i in range(1):
    for j in range(10):
        spisok_mob_1_l.append(pygame.transform.scale(pic.subsurface(pygame.Rect((32 * j, 54), (32, 9))), (25, 25)))
spisok_mob_1_r = []
for i in spisok_mob_1_l:
    spisok_mob_1_r.append(pygame.transform.flip(i, True, False))

spisok_mob_2_l = []
for i in range(1):
    for j in range(10):
        spisok_mob_2_l.append(pygame.transform.scale(pic.subsurface(pygame.Rect((32 * j, 214), (32, 9))), (25, 25)))
spisok_mob_2_r = []
for i in spisok_mob_2_l:
    spisok_mob_2_r.append(pygame.transform.flip(i, True, False))

spisok_mob_3_l = []
for i in range(1):
    for j in range(10):
        spisok_mob_3_l.append(pygame.transform.scale(pic.subsurface(pygame.Rect((32 * j, 374), (32, 9))), (25, 25)))
spisok_mob_3_r = []
for i in spisok_mob_3_l:
    spisok_mob_3_r.append(pygame.transform.flip(i, True, False))

pic = pygame.image.load('orc.png')
spisok_mob_1_l_b = []
for i in range(1):
    for j in range(10):
        spisok_mob_1_l_b.append(pygame.transform.scale(pic.subsurface(pygame.Rect((32 * j, 64), (32, 32))), (25, 50)))
spisok_mob_1_r_b = []
for i in spisok_mob_1_l_b:
    spisok_mob_1_r_b.append(pygame.transform.flip(i, True, False))

spisok_mob_2_l_b = []
for i in range(1):
    for j in range(10):
        spisok_mob_2_l_b.append(pygame.transform.scale(pic.subsurface(pygame.Rect((32 * j, 226), (32, 32))), (25, 50)))
spisok_mob_2_r_b = []
for i in spisok_mob_2_l_b:
    spisok_mob_2_r_b.append(pygame.transform.flip(i, True, False))

pic = pygame.image.load('goblin.png')
spisok_mob_3_l_b = []
for i in range(1):
    for j in range(10):
        spisok_mob_3_l_b.append(pygame.transform.scale(pic.subsurface(pygame.Rect((32 * j, 75), (32, 21))), (25, 50)))
spisok_mob_3_r_b = []
for i in spisok_mob_3_l_b:
    spisok_mob_3_r_b.append(pygame.transform.flip(i, True, False))

pic = pygame.image.load('run.png')
spisok_run_r = []
for i in range(1):
    for j in range(8):
        z = pic.subsurface(pygame.Rect((51 * j, 7), (51, 47)))
        z.set_colorkey((255, 255, 255))
        spisok_run_r.append(pygame.transform.scale(z, (25, 50)))
spisok_run_l = []
for i in spisok_run_r:
    spisok_run_l.append(pygame.transform.flip(i, True, False))

pic = pygame.image.load('crouch_im_sp.png')
spisok_crouch_r = []
for i in range(1):
    for j in range(4):
        z = pic.subsurface(pygame.Rect((72 * j, 12), (72, 42)))
        z.set_colorkey((255, 255, 255))
        spisok_crouch_r.append(pygame.transform.scale(z, (25, 25)))
spisok_crouch_l = []
for i in spisok_crouch_r:
    spisok_crouch_l.append(pygame.transform.flip(i, True, False))

pic = pygame.image.load('stand.png')
stans_r = []
z = pic.subsurface(pygame.Rect((0, 0), (51, 51)))
z.set_colorkey((255, 255, 255))
stans_r.append(pygame.transform.scale(z, (25, 50)))
stans_l = []

for i in stans_r:
    stans_l.append(pygame.transform.flip(i, True, False))

jump_r = []
pic = pygame.image.load('jump_im.png')
z = pic.subsurface(pygame.Rect((0, 0), (52, 52)))
z.set_colorkey((255, 255, 255))
jump_r.append(pygame.transform.scale(z, (25, 50)))
jump_l = []
for i in jump_r:
    jump_l.append(pygame.transform.flip(i, True, False))

lvl_1_im = pygame.transform.scale(pygame.image.load('lvl_1.png'), (25, 25))
lvl_1_im.set_colorkey((255, 255, 255))
lvl_2_im = pygame.transform.scale(pygame.image.load('lvl_2.png'), (25, 25))
lvl_2_im.set_colorkey((255, 255, 255))
lvl_3_im = pygame.transform.scale(pygame.image.load('lvl_3.png'), (25, 25))
lvl_3_im.set_colorkey((255, 255, 255))
escape_im = pygame.transform.scale(pygame.image.load('escape.png'), (50, 50))
escape_im.set_colorkey((255, 255, 255))

fire_im_r = pygame.transform.scale(pygame.image.load('fire_im.png'), (12, 12))
fire_im_r.set_colorkey((255, 255, 255))
fire_im_l = pygame.transform.flip(fire_im_r, True, False)
start_screen_image = pygame.image.load('start screen.png')
select_level = pygame.image.load('select_level.png')
enter_ur_name = pygame.image.load('name.png')
stop_screen_img = pygame.image.load('pause_screen.png')
score_board_main_im = pygame.image.load('score_board_main_img.png')
score_board_lvl_1_im = pygame.image.load('score_board_lvl_1.png')
score_board_lvl_2_im = pygame.image.load('score_board_lvl_2.png')
score_board_lvl_3_im = pygame.image.load('score_board_lvl_3.png')
escape_screen_im = pygame.image.load('escape_cong.png')
dead_screen_im = pygame.image.load('dead_im.png')
score_board_menu_im = pygame.image.load('score_board_menu.png')
screen_im = pygame.image.load('loading_screen.png')

trap = pygame.transform.scale(pygame.image.load('trap.png'), (25, 25))
trap.set_colorkey((255, 255, 255))

coin = [pygame.image.load('goldCoin1.png'), pygame.image.load('goldCoin2.png'), pygame.image.load('goldCoin3.png'),
        pygame.image.load('goldCoin4.png'), pygame.image.load('goldCoin5.png'), pygame.image.load('goldCoin6.png'),
        pygame.image.load('goldCoin7.png'), pygame.image.load('goldCoin8.png'), pygame.image.load('goldCoin9.png')]
#load_images
clock = pygame.time.Clock()


# sprite
class Player(pygame.sprite.Sprite):

    def __init__(self, x, y):
        super().__init__(all_sprites, player_sprite)
        self.image = stans_r[0]
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.speed_on_ground = 0
        self.speed_in_air = 0
        self.on_sprite = False
        self.lives = 8
        self.shield = 0
        self.turn = 'right'
        self.time_shoot = pygame.time.get_ticks()
        self.score = 100
        self.time_score = pygame.time.get_ticks()
        self.minus_score = 1000
        self.run_time = 0
        self.count = 0
        self.count_cruch = 0

    def update(self):
        global speed, list_platforms_for_me
        self.count += 1
        list = list_platforms_for_me
        b = pygame.time.get_ticks()
        if b - self.time_score >= self.minus_score and self.score > 0:
            self.score -= 1
            self.time_score = b
        k = pygame.key.get_pressed()
        if k[pygame.K_SPACE]:
            up = True
        else:
            up = False
        if k[pygame.K_a]:
            l = True
        else:
            l = False
        if k[pygame.K_d]:
            r = True
        else:
            r = False
        if k[pygame.K_LSHIFT]:
            crouch = True
        else:
            crouch = False

        if crouch:
            if self.on_sprite is True:
                speed = 2
                if self.image not in spisok_crouch_l and self.image not in spisok_crouch_r:
                    self.count_cruch = 0
                    self.rect = Rect(self.rect.x, self.rect.y + 25, 25, 25)
                    if self.turn == 'right':
                        self.image = spisok_crouch_r[0]
                        self.count_cruch = 0
                    else:
                        self.image = spisok_crouch_l[0]
                        self.count_cruch = 0
                else:
                    self.count_cruch += 1

            else:
                speed = 8
        else:
            if self.image in spisok_crouch_l or self.image in spisok_crouch_r:
                count = 0
                self.rect = Rect(self.rect.x, self.rect.y - 25, 25, 50)
                for i in list:
                    if pygame.sprite.collide_rect(self, i):
                        count += 1
                if count >= 1:
                    self.rect = Rect(self.rect.x, self.rect.y + 25, 25, 25)
                    if self.turn == 'right':
                        self.image = spisok_crouch_r[0]
                        self.count_cruch = 0
                    else:
                        self.image = spisok_crouch_l[0]
                        self.count_cruch = 0
                    crouch = True
                else:
                    speed = 8
                    crouch = False
                    if self.turn == 'right':
                        self.image = stans_r[0]
                        self.count = 0
                    else:
                        self.image = stans_l[0]
                        self.count = 0

        if l:
            z = pygame.time.get_ticks()
            if crouch == False and z - self.run_time >= 600 and self.on_sprite == True:
                run[random.randint(0, 1)].play()
                self.run_time = pygame.time.get_ticks()
            if crouch == False and self.on_sprite == True:
                self.image = spisok_run_l[self.count // 2 % 8]
            if crouch == True and self.on_sprite == True:
                self.image = spisok_crouch_l[self.count_cruch // 2 % 4]
            if crouch == False and self.on_sprite == False and self.speed_in_air != 0:
                self.image = jump_l[0]

            self.speed_on_ground = -speed
            self.turn = 'left'

        if r:
            if crouch == False and self.on_sprite == True:
                self.image = spisok_run_r[self.count // 2 % 8]
            z = pygame.time.get_ticks()
            if crouch == False and z - self.run_time >= 600 and self.on_sprite == True:
                run[random.randint(0, 1)].play()
                self.run_time = pygame.time.get_ticks()
            if crouch == True and self.on_sprite == True:
                self.image = spisok_crouch_r[self.count_cruch // 2 % 4]
            if crouch == False and self.on_sprite == False and self.speed_in_air != 0:
                self.image = jump_r[0]

            self.speed_on_ground = speed
            self.turn = 'right'

        if l is False and r is False:
            self.speed_on_ground = 0

        if l is False and r is False and self.on_sprite == True and crouch == False:
            if self.turn == 'right':
                self.image = stans_r[0]
                self.count = 0
            else:
                self.image = stans_l[0]
                self.count = 0

        if up and self.on_sprite and crouch == False:
            self.speed_in_air = jump
            self.on_sprite = False
            if self.turn == 'right':
                self.image = jump_r[0]
            else:
                self.image = jump_l[0]

        if self.on_sprite is False:
            self.speed_in_air += F_Down

        self.on_sprite = False
        self.rect.x += self.speed_on_ground
        for i in list:
            if pygame.sprite.collide_rect(self, i):
                if self.speed_on_ground > 0:
                    self.rect.right = i.rect.left
                if self.speed_on_ground < 0:
                    self.rect.left = i.rect.right
        self.rect.y += self.speed_in_air
        for i in list:
            if pygame.sprite.collide_rect(self, i):
                if self.speed_in_air > 0:
                    self.speed_in_air = 0
                    self.rect.bottom = i.rect.top
                    self.on_sprite = True
                if self.speed_in_air < 0:
                    self.speed_in_air = 0
                    self.rect.top = i.rect.bottom
        if k[pygame.K_s]:
            if pygame.time.get_ticks() - ak.time_reload >= 2000:
                self.shoot(crouch, self.speed_on_ground)

    def shoot(self, crouch, speed):
        time = pygame.time.get_ticks()
        if time - self.time_shoot >= 100 and ak.rel is False:
            self.time_shoot = time
            if ak.clip != 0:
                if self.turn == 'left':
                    z = -1
                else:
                    z = 1
                if crouch == False and self.turn == 'right':
                    q = 0
                    if speed == 8:
                        q = 8
                    bullet = Bullet(self.rect.center[0] + (25 // 2 + 8) * z - 10, 400 - 7, self.turn)
                    screen.blit(fire_im_r, (self.rect.center[0] + 20 * z - 10 - q, 400 - 11))

                if crouch == True and self.turn == 'right':
                    q = 0
                    if speed == 8:
                        q = 8
                    bullet = Bullet(self.rect.center[0] + (25 // 2 + 8) * z - 10, 400 + 6, self.turn)
                    screen.blit(fire_im_r, (self.rect.center[0] + 20 * z - 10 - q, 400 + 2))

                if crouch == False and self.turn == 'left':
                    q = 0
                    if speed == -8:
                        q = 8
                    bullet = Bullet(self.rect.center[0] + (25 // 2 + 8) * z + q, 400 - 7, self.turn)
                    screen.blit(fire_im_l, (self.rect.center[0] + 20 * z + q - 2, 400 - 11))

                if crouch == True and self.turn == 'left':
                    q = 0
                    if speed == -8:
                        q = 8
                    bullet = Bullet(self.rect.center[0] + (25 // 2 + 8) * z + q, 400 + 6, self.turn)
                    screen.blit(fire_im_l, (self.rect.center[0] + 20 * z + q, 400 + 2))
                sound_fire_1.play()
                list_bullet.append(bullet)
                ak.clip -= 1
            elif ak.clip == 0:
                sound_fire_3.play()


class Platform(pygame.sprite.Sprite):

    def __init__(self, x, y, level):
        super().__init__(all_sprites, lvl_sprite)
        if level == 1:
            self.image = lvl_1_im
        elif level == 2:
            self.image = lvl_2_im
        else:
            self.image = lvl_3_im
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y


class Trap(pygame.sprite.Sprite):

    def __init__(self, x, y):
        super().__init__(all_sprites, lvl_sprite, trap_sprite)
        self.image = trap
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y


class Camera:
    def __init__(self):
        self.dx = 0
        self.dy = 0

    def apply(self, obj):
        obj.rect.x += self.dx
        obj.rect.y += self.dy

    def update(self, target):
        self.dx = -(target.rect.x + target.rect.w // 2 - w // 2)
        self.dy = -(target.rect.y + target.rect.h // 2 - h // 2)


class AK(pygame.sprite.Sprite):
    image = pygame.transform.scale(ak_im, (150, 150))

    def __init__(self, x, y):
        super().__init__(all_sprites, gun_sprite)
        self.image = AK.image
        self.rect = self.image.get_rect()
        self.cartridges = 90
        self.clip = 30
        self.magazine_size = 30
        self.rect.x = x
        self.rect.y = y
        self.time_reload = 2000
        self.time_now = 0
        self.rel = False

    def update(self):
        k = pygame.key.get_pressed()
        if k[pygame.K_r]:
            if self.cartridges != 0 and ak.clip != 30 and self.rel != True:
                self.time_now = pygame.time.get_ticks()
                sound_fire_2.play()
                self.rel = True
                need_to_rel = self.magazine_size - self.clip
                if self.cartridges - need_to_rel <= 0:
                    self.clip += self.cartridges
                    self.cartridges = 0
                else:
                    self.clip = 30
                    self.cartridges = self.cartridges - need_to_rel
        if self.rel:
            z = pygame.time.get_ticks()
            if z - self.time_now >= self.time_reload:
                self.rel = False

    def draw(self, screen):
        screen.blit(self.image, (self.rect.x, self.rect.y))
        if self.clip == 0 and self.cartridges == 0:
            text = pygame.font.Font(None, 20).render(
                f"no ammo", True, (pygame.Color('Red')))
            place = text.get_rect(center=(240, 775))
            screen.blit(text, place)
        else:
            text = pygame.font.Font(None, 18).render(
                f"{self.clip}\{self.cartridges}", True, (pygame.Color('Black')))
            place = text.get_rect(center=(240, 775))
            screen.blit(text, place)


class Bullet(pygame.sprite.Sprite):

    def __init__(self, x, y, turn):
        super().__init__(all_sprites, bullet_sprite)
        self.image = bull_im
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.turn = turn
        self.speed = 13
        self.change = 0

    def update(self):
        self.rect.y += self.change
        if self.turn == 'left':
            self.rect.x -= self.speed
        else:
            self.rect.x += self.speed


class Mob(pygame.sprite.Sprite):

    def __init__(self, x, y):
        super().__init__(all_sprites, mob_sprite)
        self.lives = random.randint(3, 6)
        self.lvl = int(self.lives // 2)
        self.big_small = random.randint(1, 2)
        if self.big_small == 1:
            self.image = spisok_mob_1_l[1]
        else:
            self.image = spisok_mob_1_l_b[1]
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y + (25 * self.big_small - 1)
        self.speed_on_ground = 6
        self.speed_in_air = 0
        self.on_sprite = True
        self.score = 15 * self.lives
        self.count = 0

    def update(self):
        self.count += 1
        if self.big_small == 1 and self.speed_on_ground < 0 and self.count % 2 == 0 and self.lvl == 1:
            self.image = spisok_mob_1_l[self.count // 2 % 10]
        elif self.big_small == 1 and self.speed_on_ground > 0 and self.count % 2 == 0 and self.lvl == 1:
            self.image = spisok_mob_1_r[self.count // 2 % 10]

        if self.big_small == 1 and self.speed_on_ground < 0 and self.count % 2 == 0 and self.lvl == 2:
            self.image = spisok_mob_2_l[self.count // 2 % 10]
        elif self.big_small == 1 and self.speed_on_ground > 0 and self.count % 2 == 0 and self.lvl == 2:
            self.image = spisok_mob_2_r[self.count // 2 % 10]

        if self.big_small == 1 and self.speed_on_ground < 0 and self.count % 2 == 0 and self.lvl == 3:
            self.image = spisok_mob_3_l[self.count // 2 % 10]
        elif self.big_small == 1 and self.speed_on_ground > 0 and self.count % 2 == 0 and self.lvl == 3:
            self.image = spisok_mob_3_r[self.count // 2 % 10]

        if self.big_small == 2 and self.speed_on_ground < 0 and self.count % 5 == 0 and self.lvl == 1:
            self.image = spisok_mob_1_r_b[self.count // 5 % 10]
        elif self.big_small == 2 and self.speed_on_ground > 0 and self.count % 5 == 0 and self.lvl == 1:
            self.image = spisok_mob_1_l_b[self.count // 5 % 10]

        if self.big_small == 2 and self.speed_on_ground < 0 and self.count % 5 == 0 and self.lvl == 2:
            self.image = spisok_mob_2_r_b[self.count // 5 % 10]
        elif self.big_small == 2 and self.speed_on_ground > 0 and self.count % 5 == 0 and self.lvl == 2:
            self.image = spisok_mob_2_l_b[self.count // 5 % 10]

        if self.big_small == 2 and self.speed_on_ground < 0 and self.count % 5 == 0 and self.lvl == 3:
            self.image = spisok_mob_3_r_b[self.count // 5 % 10]
        elif self.big_small == 2 and self.speed_on_ground > 0 and self.count % 5 == 0 and self.lvl == 3:
            self.image = spisok_mob_3_l_b[self.count // 5 % 10]

        list = list_platforms_for_me

        if self.on_sprite is False:
            self.speed_in_air += F_Down

        self.on_sprite = False

        self.rect.x += self.speed_on_ground
        count = 0
        for i in list:
            if pygame.sprite.collide_rect(self, i):
                if self.speed_on_ground > 0:
                    self.rect.right = i.rect.left
                    count += 1
                if self.speed_on_ground < 0:
                    self.rect.left = i.rect.right
                    self.speed_on_ground = 6
                    count += 2
        if count % 2 != 0:
            self.speed_on_ground = -6

        self.rect.y += self.speed_in_air
        for i in list:
            if pygame.sprite.collide_rect(self, i):
                if self.speed_in_air > 0:
                    self.speed_in_air = 0
                    self.rect.bottom = i.rect.top
                    self.on_sprite = True
                if self.speed_in_air < 0:
                    self.speed_in_air = 0
                    self.rect.top = i.rect.bottom


class Box(pygame.sprite.Sprite):
    close_im = pygame.transform.scale(cl_box_im, (25, 25))
    image = [pygame.transform.scale(box_hp, (25, 25)), pygame.transform.scale(box_sh, (25, 25)),
             pygame.transform.scale(box_bul, (25, 25)), pygame.transform.scale(box_coin, (25, 25))]

    def __init__(self, x, y):
        super().__init__(all_sprites, box_sprite)
        self.image = Box.close_im
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y
        self.type = random.randint(0, 3)
        self.close_open = 1
        self.current_im = 0

    def update(self):
        self.current_im += 1
        if self.close_open == 0 and self.type == 3 and self.current_im % 3 == 0:
            self.image = coin[(self.current_im // 3) % 9]
        elif self.close_open == 0 and self.type != 3:
            self.image = Box.image[self.type]


class End_lvl(pygame.sprite.Sprite):

    def __init__(self, x, y):
        super().__init__(all_sprites, end_lvl_sprite)
        self.image = escape_im
        self.rect = self.image.get_rect()
        self.rect.x = x
        self.rect.y = y


#func
def generate_level(level):
    for y in range(len(level)):
        for x in range(len(level[y])):
            if level[y][x] == '-':
                plat = Platform(x * 25, y * 25, num_level)
                list_platforms_for_me.append(plat)
            elif level[y][x] == '^':
                trap = Trap(x * 25, y * 25)
                list_of_traps.append(trap)
            elif level[y][x] == '*':
                player = Player(x * 25, y * 25)
                list_player.append(player)
            elif level[y][x] == '+':
                mob = Mob(x * 25, y * 25)
                list_mob.append(mob)
            elif level[y][x] == '/':
                box = Box(x * 25, y * 25)
                list_box.append(box)
            elif level[y][x] == '.':
                escape = End_lvl(x * 25, y * 25)
                list_escape.append(escape)


def Score(screen, score):
    text = pygame.font.Font(None, 40).render(
        f"score", True, (pygame.Color('Black')))
    place = text.get_rect(center=(w // 2, 745))
    screen.blit(text, place)
    text = pygame.font.Font(None, 60).render(
        f"{score}", True, (pygame.Color('Black')))
    place = text.get_rect(center=(w // 2, 775))
    screen.blit(text, place)


def HP(screen, lives):
    image = pygame.transform.scale(pygame.image.load('hp_image.png'), (35, 50))
    rect = image.get_rect()
    for i in range(lives):
        rect.y = h - 105
        rect.x = w - 30 - (i * 40)
        screen.blit(image, rect)
    if lives >= 1:
        return True
    return False


def Shield(screen, shield):
    image = pygame.transform.scale(pygame.image.load('shield_image.png'), (30, 45))
    rect = image.get_rect()
    for i in range(shield):
        rect.y = h - 50
        rect.x = w - 30 - (i * 35)
        screen.blit(image, rect)


def ur_name():
    global name_player, clear
    show = True
    time = pygame.time.get_ticks()
    while show:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if e.type == pygame.MOUSEBUTTONDOWN:
                pos = e.pos
                if 20 <= pos[0] <= 365 and 645 <= pos[1] <= 770:
                    show = False
                    main_start_screen()
                elif 875 <= pos[0] <= 1220 and 645 <= pos[1] <= 770:
                    show = False
                    select_a_level()
            k = pygame.key.get_pressed()
            if not (checker(k) is None):
                z = pygame.time.get_ticks()
                if z - time >= 150:
                    time = z
                    back = checker(k)
                    if back == 'delete' and len(name_player) >= 1:
                        name_player = name_player[:-1]
                    elif back != 'delete' and len(name_player) < 8:
                        name_player = name_player + str(back)
        if clear is True:
            screen.fill((0, 0, 0))
        elif show is True:
            screen.blit(enter_ur_name, (0, 0))
            text = pygame.font.Font(None, 200).render(
                f"{name_player}", True, (pygame.Color('Black')))
            place = text.get_rect()
            place.x = 125
            place.y = 150
            screen.blit(text, place)
        pygame.display.flip()


def load(z):
    global start_screen, name_player, update, clear
    clear = True
    show = True
    while show:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
        if pygame.time.get_ticks() - z >= 5000:
            show = False
            start_screen = False
            update = True
        screen.blit(screen_im, (0, 0))
        pygame.display.flip()


def select_a_level():
    global num_level, start_screen, name_player, update, clear
    show = True
    while show:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif e.type == pygame.MOUSEBUTTONDOWN:
                pos = e.pos
                if 20 <= pos[0] <= 365 and 645 <= pos[1] <= 770:
                    show = False
                    name_player = 'player'
                    main_start_screen()
                elif 875 <= pos[0] <= 1220 and 645 <= pos[1] <= 770:
                    show = False
                    load(pygame.time.get_ticks())
                elif 220 <= pos[0] <= 475 and 90 <= pos[1] <= 340:
                    num_level = 1
                elif 500 <= pos[0] <= 750 and 90 <= pos[1] <= 340:
                    num_level = 2
                elif 770 <= pos[0] <= 1025 and 90 <= pos[1] <= 340:
                    num_level = 3
        if clear is True:
            screen.fill((0, 0, 0))
        else:
            screen.blit(select_level, (0, 0))
            pygame.display.flip()


def main_start_screen():
    global clear
    show = True
    while show:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif e.type == pygame.MOUSEBUTTONDOWN:
                pos = e.pos
                if 420 <= pos[0] <= 780 and 220 <= pos[1] <= 320:
                    show = False
                    ur_name()
                elif 450 <= pos[0] <= 730 and 470 <= pos[1] <= 541:
                    show = False
                    score_board()
        if clear is True:
            screen.fill((0, 0, 0))
        else:
            screen.blit(start_screen_image, (0, 0))
            pygame.display.flip()


def stop_screen():
    global start_screen, name_player, screen, clear
    show = True
    while show:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif e.type == pygame.MOUSEBUTTONDOWN:
                pos = e.pos
                if 325 <= pos[0] <= 925 and 200 <= pos[1] <= 350:
                    show = False
                elif 325 <= pos[0] <= 925 and 400 <= pos[1] <= 550:
                    show = False
                    name_player = 'player'
                    main_start_screen()
        if clear is True:
            screen.fill((0, 0, 0))
        else:
            screen.blit(stop_screen_img, (0, 0))
            pygame.display.flip()


def score_board_lvl_1():
    global clear
    show = True
    while show:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif e.type == pygame.MOUSEBUTTONDOWN:
                pos = e.pos
                if 20 <= pos[0] <= 365 and 645 <= pos[1] <= 770:
                    show = False
                    score_board()
        if clear is True:
            screen.fill((0, 0, 0))
        else:
            screen.blit(score_board_lvl_1_im, (0, 0))
            con = sqlite3.connect("score.db")
            cur = con.cursor()
            result = cur.execute("""SELECT * FROM score WHERE Lvl_num == ?""", [1]).fetchall()
            spisok = sorted(result, key=lambda x: x[2], reverse=True)[:10]
            for i in range(len(spisok)):
                text = pygame.font.Font(None, 30).render(
                    f"Name {spisok[i][0]} Lvl {spisok[i][1]} Score {spisok[i][2]}", True, (pygame.Color('Black')))
                place = text.get_rect()
                place.x = 450
                place.y = 60 * (i + 1)
                screen.blit(text, place)
            con.commit()
            con.close()
            pygame.display.flip()


def score_board_lvl_2():
    global clear
    show = True
    while show:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif e.type == pygame.MOUSEBUTTONDOWN:
                pos = e.pos
                if 20 <= pos[0] <= 365 and 645 <= pos[1] <= 770:
                    show = False
                    score_board()
        if clear is True:
            screen.fill((0, 0, 0))
        else:
            screen.blit(score_board_lvl_2_im, (0, 0))
            con = sqlite3.connect("score.db")
            cur = con.cursor()
            result = cur.execute("""SELECT * FROM score
            WHERE Lvl_num == ?""", [2]).fetchall()
            spisok = sorted(result, key=lambda x: x[2], reverse=True)[:10]
            for i in range(len(spisok)):
                text = pygame.font.Font(None, 30).render(
                    f"Name {spisok[i][0]} Lvl {spisok[i][1]} Score {spisok[i][2]}", True, (pygame.Color('Black')))
                place = text.get_rect()
                place.x = 450
                place.y = 60 * (i + 1)
                screen.blit(text, place)
            pygame.display.flip()


def score_board_lvl_3():
    global clear
    show = True
    while show:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif e.type == pygame.MOUSEBUTTONDOWN:
                pos = e.pos
                if 20 <= pos[0] <= 365 and 645 <= pos[1] <= 770:
                    show = False
                    score_board()
        if clear is True:
            screen.fill((0, 0, 0))
        else:
            screen.blit(score_board_lvl_3_im, (0, 0))
            con = sqlite3.connect("score.db")
            cur = con.cursor()
            result = cur.execute("""SELECT * FROM score WHERE Lvl_num == ?""", [3]).fetchall()
            spisok = sorted(result, key=lambda x: x[2], reverse=True)[:10]
            for i in range(len(spisok)):
                text = pygame.font.Font(None, 30).render(
                    f"Name {spisok[i][0]} Lvl {spisok[i][1]} Score {spisok[i][2]}", True, (pygame.Color('Black')))
                place = text.get_rect()
                place.x = 450
                place.y = 60 * (i + 1)
                screen.blit(text, place)
            pygame.display.flip()


def score_board_all():
    global clear
    show = True
    while show:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif e.type == pygame.MOUSEBUTTONDOWN:
                pos = e.pos
                if 20 <= pos[0] <= 365 and 645 <= pos[1] <= 770:
                    show = False
                    score_board()
        if clear is True:
            screen.fill((0, 0, 0))
        else:

            screen.blit(score_board_main_im, (0, 0))
            con = sqlite3.connect("score.db")
            cur = con.cursor()
            result = cur.execute("""SELECT * FROM score""").fetchall()
            spisok = sorted(result, key=lambda x: x[2], reverse=True)[:10]
            for i in range(len(spisok)):
                text = pygame.font.Font(None, 30).render(
                    f"Name {spisok[i][0]} Lvl {spisok[i][1]} Score {spisok[i][2]}", True, (pygame.Color('Black')))
                place = text.get_rect()
                place.x = 450
                place.y = 60 * (i + 1)
                screen.blit(text, place)
            pygame.display.flip()


def score_board():
    global clear
    show = True
    while show:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif e.type == pygame.MOUSEBUTTONDOWN:
                pos = e.pos
                if 20 <= pos[0] <= 365 and 645 <= pos[1] <= 770:
                    show = False
                    main_start_screen()
                elif 875 <= pos[0] <= 1220 and 645 <= pos[1] <= 770:
                    show = False
                    score_board_all()
                elif 475 <= pos[0] <= 775 and 80 <= pos[1] <= 175:
                    show = False
                    score_board_lvl_1()
                elif 475 <= pos[0] <= 775 and 225 <= pos[1] <= 330:
                    show = False
                    score_board_lvl_2()
                elif 475 <= pos[0] <= 775 and 375 <= pos[1] <= 485:
                    show = False
                    score_board_lvl_3()
        if clear is True:
            screen.fill((0, 0, 0))
        elif show is True:
            screen.blit(score_board_menu_im, (0, 0))
            pygame.display.flip()


def escape_gg(a, b, c):
    global clear
    global name_player
    # обновление бд добавление значение с новым именем если это имя уже есть в бд то заменить на новую информацию
    show = True
    sound_lvl_end.play()
    while show:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif e.type == pygame.MOUSEBUTTONDOWN:
                pos = e.pos
                if 20 <= pos[0] <= 365 and 645 <= pos[1] <= 770:
                    show = False
                    name_player = 'player'
                    main_start_screen()
                elif 875 <= pos[0] <= 1220 and 645 <= pos[1] <= 770:
                    show = False
                    select_a_level()
        if clear is True:
            screen.fill((0, 0, 0))
        elif show is True:
            screen.blit(escape_screen_im, (0, 0))
            text2 = pygame.font.Font(None, 30).render(
                f"Name {name_player}", True, (pygame.Color('Black')))
            place2 = text2.get_rect()
            place2.x = 500
            place2.y = 120
            screen.blit(text2, place2)

            con = sqlite3.connect("score.db")
            cur = con.cursor()
            result = cur.execute("""SELECT * FROM score""").fetchall()
            spisok = sorted(result, key=lambda x: x[2], reverse=True)
            count = 1
            index = 0
            for i in spisok:
                if i[0] == a and i[1] == b and i[2] == c:
                    index = count
                count += 1
            text = pygame.font.Font(None, 30).render(
                f"Вы заняли {index} место в общем райтенге", True, (pygame.Color('Black')))
            place = text.get_rect()
            place.x = 450
            place.y = 240
            screen.blit(text, place)
            result1 = cur.execute("""SELECT * FROM score WHERE Lvl_num == ?""", [b]).fetchall()
            spisok1 = sorted(result1, key=lambda y: y[2], reverse=True)
            count1 = 1
            index1 = 0
            for i in spisok1:
                if i[0] == a and i[1] == b and i[2] == c:
                    index1 = count1
                count1 += 1
            text1 = pygame.font.Font(None, 30).render(
                f"Вы заняли {index1} место в Lvl{b} райтенге", True, (pygame.Color('Black')))
            place1 = text1.get_rect()
            place1.x = 450
            place1.y = 360
            screen.blit(text1, place1)

            text3 = pygame.font.Font(None, 30).render(
                f"Ваш счёт {c}", True, (pygame.Color('Black')))
            place3 = text2.get_rect()
            place3.x = 525
            place3.y = 480
            screen.blit(text3, place3)
            pygame.display.flip()


def dead_screen():
    global start_screen, name_player, clear
    show = True
    player_dead.play()
    while show:
        for e in pygame.event.get():
            if e.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            elif e.type == pygame.MOUSEBUTTONDOWN:
                pos = e.pos
                if 325 <= pos[0] <= 925 and 550 <= pos[1] <= 700:
                    name_player = 'player'
                    main_start_screen()
                    show = False
        if clear is True:
            screen.fill((0, 0, 0))
        elif show is True:
            screen.blit(dead_screen_im, (0, 0))
            pygame.display.flip()
#func
#main
while game:
    clock.tick(30)
    if start_screen:
        screen = pygame.display.set_mode((w, h))
        main_start_screen()
        start_screen = False
    if update:
        screen = pygame.display.set_mode((w, h))
        l = False
        r = False
        up = False
        on_sprite = False
        crouch = False
        _hp = 0
        _sh = 0
        speed = 8
        jump = -15
        F_Down = 1
        list_platforms_for_me = []
        platforms = []
        list_of_traps = []
        list_bullet = []
        list_box = []
        list_player = []
        list_escape = []
        all_sprites = pygame.sprite.Group()
        player_sprite = pygame.sprite.Group()
        lvl_sprite = pygame.sprite.Group()
        trap_sprite = pygame.sprite.Group()
        gun_sprite = pygame.sprite.Group()
        bullet_sprite = pygame.sprite.Group()
        mob_sprite = pygame.sprite.Group()
        box_sprite = pygame.sprite.Group()
        end_lvl_sprite = pygame.sprite.Group()

        camera = Camera()
        ak = AK(0, 650)
        generate_level(level[num_level - 1])
        update = False
        clear = False

    for e in pygame.event.get():
        if e.type == pygame.QUIT:
            game = False
    k = pygame.key.get_pressed()

    if k[pygame.K_ESCAPE]:
        if stop_screen_v is False:
            stop_screen()
            stop_screen_v = True
        if stop_screen_v:
            stop_screen_v = False

    screen.blit(bg, (0, 0))
    camera.update(list_player[0])
    for sprite in all_sprites:
        if sprite in gun_sprite:
            pass
        else:
            camera.apply(sprite)
    all_sprites.draw(screen)
    for i in gun_sprite:
        i.draw(screen)
    all_sprites.update()

    if pygame.sprite.groupcollide(player_sprite, trap_sprite, False, False):
        dead_screen()

    for i in list_bullet:
        for j in list_platforms_for_me:
            if pygame.sprite.collide_rect(i, j):
                lvl_dd.play()
                if i in list_bullet:
                    list_bullet.remove(i)
                i.kill()

    for i in list_bullet:
        for j in list_mob:
            if pygame.sprite.collide_rect(i, j):
                j.lives -= 1
                mob_dd[random.randint(0, 2)].play()
                if j.lives == 0:
                    list_player[0].score += j.score
                    j.kill()
                    list_mob.remove(j)
                    monster_dd.play()
                if i in list_bullet:
                    list_bullet.remove(i)
                i.kill()

    for i in list_bullet:
        for j in list_box:
            if pygame.sprite.collide_rect(i, j):
                if j.close_open != 0:
                    i.kill()
                    j.close_open = 0
                    list_bullet.remove(i)

    for i in list_box:
        for j in list_player:
            if pygame.sprite.collide_rect(j, i):
                if i.close_open == 0:
                    if i.type == 0:
                        if j.lives < 8:
                            sound_med_up.play()
                            j.lives += random.randint(1, 3)
                            if j.lives > 8:
                                j.lives = 8
                            list_box.remove(i)
                            i.kill()
                    elif i.type == 1:
                        if j.shield < 5:
                            sound_shield_up.play()
                            j.shield += random.randint(1, 2)
                            if j.shield > 5:
                                j.shield = 5
                            list_box.remove(i)
                            i.kill()
                    elif i.type == 2:
                        if ak.cartridges != 90:
                            sound_bullet_up.play()
                            ak.cartridges += random.randint(10, 30)
                            if ak.cartridges > 90:
                                ak.cartridges = 90
                            list_box.remove(i)
                            i.kill()
                    else:
                        sound_coin_up.play()
                        j.score += random.randint(10, 30)
                        list_box.remove(i)
                        i.kill()

    for i in list_mob:
        for f in list_player:
            if pygame.sprite.collide_rect(f, i):
                damage = int(i.lives // 2)
                for j in range(damage):
                    f.score -= 5
                    if f.shield != 0:
                        f.shield -= 1
                        z = pygame.time.get_ticks()
                        if z - _sh >= 350:
                            player_sh.play()
                            _sh = z
                    else:
                        f.lives -= 1
                        z = pygame.time.get_ticks()
                        if z - _hp >= 600:
                            player_hp.play()
                            _hp = z
                i.kill()
                list_mob.remove(i)
                if f.score < 0:
                    f.score = 0

    for i in list_player:
        for j in list_escape:
            if pygame.sprite.collide_rect(i, j):
                if k[pygame.K_e]:
                    con = sqlite3.connect("score.db")
                    cur = con.cursor()
                    result = cur.execute("""SELECT * FROM score
                        WHERE Lvl_num == (?)""", [num_level]).fetchall()
                    spisok = []
                    spisok_check = []
                    for f in result:
                        spisok.append(f)
                        spisok_check.append(f[0])
                    count = 0
                    if name_player in spisok_check:
                        while True:
                            if name_player not in spisok_check:
                                break
                            else:
                                name_player = name_player + str(count)
                                count += 1
                    cur.execute('''INSERT INTO score(Name,Lvl_num,Score) VALUES(?,?,?)''',
                                [name_player, num_level, i.score])
                    con.commit()
                    con.close()
                    escape_gg(name_player, num_level, i.score)

    HP(screen, list_player[0].lives)
    Shield(screen, list_player[0].shield)
    Score(screen, list_player[0].score)

    if list_player[0].lives <= 0:
        dead_screen()

    pygame.display.flip()
# main
pygame.quit()
